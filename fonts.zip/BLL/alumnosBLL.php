<?php
require_once 'model/alumno.php';

class alumnosBLL{

    private $model;

    public function __CONSTRUCT(){
        $this->model = new alumno();
    }

    //Verificar si existe un email existente
    public function checkEmail($email){
        $result=false;
            foreach($this->model->Listar() as $r):
                if($r->email==$email)
                {
                    $result= true;
                }
            endforeach;
        return $result;
    }
}

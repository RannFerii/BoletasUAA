<?php
require_once 'model/alumno.php';
require_once 'BLL/alumnosBLL.php';

class AlumnoController{

    private $model;
    private $BLL;

    public function __CONSTRUCT(){
        $this->model = new alumno();
        $this->BLL = new alumnosBLL();
    }

    //Vista por default
    public function Index(){
        require_once 'Views/header/dataTableReport.php';
        require_once 'Views/alumno/index.php';
        require_once 'Views/footer/BeginFooter.php';
        require_once 'Views/footer/ScriptDataTableReport.php';
        require_once 'Views/footer/ScriptButton.php';
         require_once 'Views/footer/ScriptSweetAlert.php';
        require_once 'Views/footer/EndFooter.php';
    }

    public function Reporte(){
        require_once 'Views/header/dataTableReport.php';
        require_once 'Views/alumno/reportes.php';
        require_once 'Views/footer/BeginFooter.php';
        require_once 'Views/footer/ScriptDataTableReport.php';
        require_once 'Views/footer/EndFooter.php';
    }

    //Cargar formulario
    public function Agregar(){
        $alumno = new alumno();
        require_once 'Views/header/dataTableReport.php';
        require_once 'Views/alumno/agregar.php';
        require_once 'Views/footer/BeginFooter.php';
        require_once 'Views/footer/ScriptValidation.php';
        require_once 'Views/footer/ScriptNotification.php';
        require_once 'Views/footer/ScriptMessageError.php';
        require_once 'Views/footer/EndFooter.php';
    }

    //Guardar form 
    public function Guardar(){
        $alumno = new alumno();
        $alumno->matriculaUAA = $_REQUEST['matriculaUAA'];
        $alumno->matriculaUNAM = $_REQUEST['matriculaUNAM'];
        $alumno->nombre = $_REQUEST['nombre'];
        $alumno->apellidoPaterno = $_REQUEST['apellidoPaterno'];
        $alumno->apellidoMaterno = $_REQUEST['apellidoMaterno'];
        $alumno->email = $_REQUEST['email'];
        $alumno->telefono = $_REQUEST['telefono'];

        $actionResult= "";
        if($this->BLL->checkEmail($alumno->email)==true)
        {
            $_SESSION['mensajeError'] = "correo electrónico existente,prueba con otro";
            $actionResult='Location: index.php?c=alumno&a=Agregar';
            
        }else
        {
            $this->model->Registrar($alumno);
             $actionResult='Location: index.php?c=alumno';
        }

        header($actionResult);
       
    }

    //Cargar Form
    public function Editar(){
        $alumno = new alumno();
        if(isset($_REQUEST['matriculaUAA'])) {
            $alumno = $this->model->Obtener($_REQUEST['matriculaUAA']);
        }
        require_once 'Views/header/dataTableReport.php';
        require_once 'Views/alumno/Editar.php';
        require_once 'Views/footer/BeginFooter.php';
        require_once 'Views/footer/ScriptValidation.php';
        require_once 'Views/footer/ScriptNotification.php';
        require_once 'Views/footer/EndFooter.php';
    }

    //Guardar nuevos cambios
    public function Actualizar(){
        $alumno = new alumno();

        $alumno->matriculaUAA = $_REQUEST['matriculaUAA'];
        $alumno->matriculaUNAM = $_REQUEST['matriculaUNAM'];
        $alumno->nombre = $_REQUEST['nombre'];
        $alumno->apellidoPaterno = $_REQUEST['apellidoPaterno'];
        $alumno->apellidoMaterno = $_REQUEST['apellidoMaterno'];
        $alumno->email = $_REQUEST['email'];
        $alumno->telefono = $_REQUEST['telefono'];

        $this->model->Actualizar($alumno);

        header('Location: index.php?c=alumno');
    }

    public function Eliminar(){
        $this->model->Eliminar($_REQUEST['matriculaUAA']);
        header('Location: index.php');
    }
}

<!--DatePicker-->
<!-- IMPORTANTE: En caso de configuracion para las clases especiales de DatePicker 
	revisar : js/custom_js/datepickers.js -->
	
<!-- InputMask -->
<script src="vendors/moment/js/moment.min.js" type="text/javascript"></script>
<script src="vendors/inputmask/inputmask/inputmask.js" type="text/javascript"></script>
<script src="vendors/inputmask/inputmask/jquery.inputmask.js" type="text/javascript"></script>
<script src="vendors/inputmask/inputmask/inputmask.date.extensions.js" type="text/javascript"></script>
<script src="vendors/inputmask/inputmask/inputmask.extensions.js" type="text/javascript"></script>
<!-- date-range-picker -->
<script src="vendors/daterangepicker/js/daterangepicker.js" type="text/javascript"></script>
<!-- bootstrap time picker -->
<script src="vendors/datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
<script src="vendors/clockpicker/js/bootstrap-clockpicker.min.js" type="text/javascript"></script>
<script src="vendors/jquerydaterangepicker/js/jquery.daterangepicker.min.js" type="text/javascript"></script>
<script src="vendors/datedropper/datedropper.js" type="text/javascript"></script>
<script src="vendors/timedropper/js/timedropper.js" type="text/javascript"></script>
<script src="js/custom_js/datepickers.js" type="text/javascript"></script>
<script src="js/custom_uaa/fecha.js" type="text/javascript"></script>
<!-- DropDown Select2 -->
<script src="vendors/bootstrap-multiselect/js/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="vendors/select2/js/select2.js" type="text/javascript"></script>
<script src="vendors/selectize/js/standalone/selectize.min.js" type="text/javascript"></script>
<script src="vendors/iCheck/js/icheck.js" type="text/javascript"></script>
<script src="vendors/selectric/js/jquery.selectric.min.js" type="text/javascript"></script>
<script src="js/custom_js/custom_elements.js" type="text/javascript"></script>
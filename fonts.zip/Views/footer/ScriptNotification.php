<!-- Notificaciones -->
<script type="text/javascript" src="vendors/pnotify/js/pnotify.js"></script>
<script type="text/javascript" src="vendors/pnotify/js/pnotify.animate.js"></script>
<script type="text/javascript" src="vendors/pnotify/js/pnotify.buttons.js"></script>
<script type="text/javascript" src="vendors/pnotify/js/pnotify.confirm.js"></script>
<script type="text/javascript" src="vendors/pnotify/js/pnotify.nonblock.js"></script>
<script type="text/javascript" src="vendors/pnotify/js/pnotify.mobile.js"></script>
<script type="text/javascript" src="vendors/pnotify/js/pnotify.desktop.js"></script>
<script type="text/javascript" src="vendors/pnotify/js/pnotify.history.js"></script>
<script type="text/javascript" src="vendors/pnotify/js/pnotify.callbacks.js"></script>
<script src="js/custom_js/notifications.js"></script>
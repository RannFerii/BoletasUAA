<script type="text/javascript" src="vendors/sweetalert2/js/sweetalert2.min.js"></script>
<script type="text/javascript" src="js/custom_js/sweetalert.js"></script>

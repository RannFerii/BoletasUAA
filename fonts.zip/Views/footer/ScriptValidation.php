<!--Validaciones -->
<script type="text/javascript" src="vendors/bootstrapvalidator/js/bootstrapValidator.min.js"></script>
<!--<script type="text/javascript" src="vendors/bootstrap-maxlength/js/bootstrap-maxlength.js"></script>-->
<script type="text/javascript" src="vendors/sweetalert2/js/sweetalert2.min.js"></script>
<script type="text/javascript" src="vendors/card/jquery.card.js"></script>
<script type="text/javascript" src="vendors/iCheck/js/icheck.js"></script>
<script src="js/passtrength/passtrength.js"></script>
<script type="text/javascript" src="js/custom_js/form2.js"></script>
<script src="http://mimo84.github.io/bootstrap-maxlength/bower_components/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
<script type="text/javascript" src="js/custom_js/form3.js"></script>
<script type="text/javascript" src="js/custom_js/form_validations.js"></script>

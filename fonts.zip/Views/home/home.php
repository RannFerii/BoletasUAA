

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="swiper-container swiper_news">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide slide-1 gradient-color">
                            <div class="slider-content">
                                <div class="news-head">
                                    <h3>Sistema Generador de Boletas UAA</h3>
                                    <span class="pull-right">2018</span>
                                    <hr>
                                </div>
                                <div class="news-cont">
                                    <h4> En desarrollo</h4>
                                    <!-- <p class="text-right read-more"><a class="read-more"
                                                                       href="javascript:void(0)">Read
                                        more <i class="ti-angle-double-right"></i></a></p> -->
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide slide-2 gradient-color">
                            <div class="slider-content">
                                <div class="news-head">
                                    <h3>What to expect in the final race..</h3>
                                    <span class="pull-right">5min ago</span>
                                    <hr>
                                </div>
                                <div class="news-cont">
                                    <h4>The strategy of adjusting and optimizing energy, using systems
                                        and
                                        procedures so as to reduce energy per unit of output
                                        while holding ...</h4>
                                    <p class="text-right read-more"><a class="read-more"
                                                                       href="javascript:void(0)">Read
                                        more <i class="ti-angle-double-right"></i></a></p>

                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide slide-3 gradient-color">
                            <div class="slider-content">
                                <div class="news-head">
                                    <h3>First ever Largest open Air Purifier</h3>
                                    <span class="pull-right">On 28th Oct</span>
                                    <hr>
                                </div>
                                <div class="news-cont">
                                    <h4>The strategy of adjusting and optimizing energy, using systems
                                        and
                                        procedures so as to reduce energy requirements per unit of
                                        output
                                        while holding ...</h4>
                                    <p class="text-right read-more"><a class="read-more"
                                                                       href="javascript:void(0)">Read
                                        more <i class="ti-angle-double-right"></i></a></p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>




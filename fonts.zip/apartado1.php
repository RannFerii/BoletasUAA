<?php
require_once("db/database.php");
require_once("Controllers/SectionController.php");
?>
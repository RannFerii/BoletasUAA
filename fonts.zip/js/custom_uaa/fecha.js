 $('.fechaPrimerDepartamental').dateRangePicker({
        singleDate: true,
        showShortcuts: false,
        singleMonth: true,
        getValue: function () {
            $(this).val("");
        }
    });

    $('.fechaSegundoDepartamental').dateRangePicker({
        singleDate: true,
        showShortcuts: false,
        singleMonth: true,
        getValue: function () {
            $(this).val("");
        }
    });

    $('.fechaParcial').dateRangePicker({
        singleDate: true,
        showShortcuts: false,
        singleMonth: true,
        getValue: function () {
            $(this).val("");
        }
    });

     $('.fechaFinalA').dateRangePicker({
        singleDate: true,
        showShortcuts: false,
        singleMonth: true,
        getValue: function () {
            $(this).val("");
        }
    });

     $('.fechaFinalB').dateRangePicker({
        singleDate: true,
        showShortcuts: false,
        singleMonth: true,
        getValue: function () {
            $(this).val("");
        }
    });

